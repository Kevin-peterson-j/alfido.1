document.addEventListener('DOMContentLoaded', function () {

  // ----- Footer year -----
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // ----- Smooth scroll for nav links (with fixed navbar offset) -----
  const navbar = document.getElementById('mainNav');
  const smoothLinks = document.querySelectorAll('.smooth-scroll');
  const bsCollapseEl = document.getElementById('navMenu');

  smoothLinks.forEach(link => {
    link.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (!targetId || targetId === '#') return;
      const targetEl = document.querySelector(targetId);
      if (!targetEl) return;

      e.preventDefault();
      const offset = navbar ? navbar.offsetHeight : 0;
      const top = targetEl.getBoundingClientRect().top + window.pageYOffset - offset + 1;

      window.scrollTo({ top, behavior: 'smooth' });

      // Close mobile menu after clicking a link
      if (bsCollapseEl && bsCollapseEl.classList.contains('show')) {
        const collapse = bootstrap.Collapse.getOrCreateInstance(bsCollapseEl);
        collapse.hide();
      }
    });
  });

  // ----- Active nav link highlighting on scroll -----
  const sections = document.querySelectorAll('section[id], header[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  function setActiveLink() {
    let currentId = '';
    const scrollPos = window.pageYOffset + (navbar ? navbar.offsetHeight : 0) + 20;

    sections.forEach(section => {
      if (scrollPos >= section.offsetTop) {
        currentId = section.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.classList.toggle('active', link.getAttribute('href') === '#' + currentId);
    });
  }

  window.addEventListener('scroll', setActiveLink);
  setActiveLink();

  // ----- Back to top button -----
  const backToTop = document.querySelector('.back-to-top');
  function toggleBackToTop() {
    if (window.pageYOffset > 500) {
      backToTop.classList.add('show');
    } else {
      backToTop.classList.remove('show');
    }
  }
  window.addEventListener('scroll', toggleBackToTop);
  toggleBackToTop();

  // ----- Contact form (front-end demo only) -----
  const form = document.getElementById('contactForm');
  const formNote = document.getElementById('formNote');

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      // NOTE: This is a front-end only demo.
      // To make this form actually send messages, connect it to a service
      // like Formspree, EmailJS, Netlify Forms, or your own backend endpoint.
      formNote.textContent = 'Thanks! This is a demo form — connect it to Formspree/EmailJS to receive real messages.';
      form.reset();
    });
  }

});

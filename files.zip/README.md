# Alex Morgan — Portfolio Website

A mobile-friendly, single-page personal portfolio built with **HTML, CSS, Bootstrap 5, and vanilla JavaScript**. No build tools or frameworks required — just open `index.html` in a browser.

**Sections:** Home · Skills · Projects · Contact
**Design direction:** a "blueprint / technical schematic" aesthetic — dark navy grid background, cyan/amber accents, monospace section labels — built to suit a developer portfolio.

---

## 📁 File structure

```
portfolio/
├── index.html        # All page content/markup
├── css/
│   └── style.css      # All custom styling (uses Bootstrap grid + custom design system)
├── js/
│   └── script.js       # Smooth scroll, active nav highlighting, back-to-top, demo contact form
└── README.md
```

## ✨ Features

- **Fully responsive** — tested down to 320px width (small phones) up through desktop
- **Bootstrap 5** navbar with collapsible hamburger menu on mobile
- **Smooth scroll** navigation with scroll-based active link highlighting
- **Accessible** — visible keyboard focus states, semantic HTML, `prefers-reduced-motion` respected
- **Zero dependencies to install** — Bootstrap, Bootstrap Icons and Google Fonts are loaded via CDN

## 🛠 Before you publish — personalize it

Open `index.html` and replace the placeholder content:

| What to change | Where |
|---|---|
| Name, title, intro text | `<header id="home">` section |
| Skills / tools | `<section id="skills">` |
| Project titles, descriptions, links, tags | `<section id="projects">` |
| Email, location, social links | `<section id="contact">` |
| Page `<title>` and meta description | `<head>` |

The contact form is **front-end only** (it just shows a confirmation message). To actually receive messages, connect it to a free service:
- [Formspree](https://formspree.io/) — easiest, no backend needed
- [EmailJS](https://www.emailjs.com/)
- Netlify Forms (if you host on Netlify instead of GitHub Pages)

## 🎨 Customizing the look

All colors, fonts, and spacing are defined as CSS variables at the top of `css/style.css`:

```css
:root{
  --ink:        #0B1020;   /* page background */
  --cyan:       #4FD1FF;   /* primary accent */
  --amber:      #FFB454;   /* secondary accent */
  --text-main:  #E8ECF5;
  --text-mute:  #9AA6C4;
}
```

Change these to re-theme the entire site.

---

## 🚀 Deploy for free on GitHub Pages

1. **Create a new GitHub repository** (e.g. `my-portfolio`) — public, no README/gitignore needed since you already have files.

2. **Push these files to it:**
   ```bash
   cd portfolio
   git init
   git add .
   git commit -m "Initial portfolio site"
   git branch -M main
   git remote add origin https://github.com/<your-username>/my-portfolio.git
   git push -u origin main
   ```

3. **Enable GitHub Pages:**
   - Go to your repo on GitHub → **Settings** → **Pages** (left sidebar)
   - Under "Build and deployment" → Source: **Deploy from a branch**
   - Branch: **main**, folder: **/ (root)** → **Save**

4. **Wait ~1 minute**, then your site will be live at:
   ```
   https://<your-username>.github.io/my-portfolio/
   ```
   (GitHub shows the exact URL at the top of the Pages settings once it's built.)

5. Any time you edit and push new commits to `main`, the live site updates automatically.

### Alternative one-click hosts
If you'd rather not use GitHub Pages, these also work with zero config for a static site like this:
- [Netlify](https://app.netlify.com/drop) — drag-and-drop the folder
- [Vercel](https://vercel.com/)

---

## License
Free to use and modify for your own portfolio.
